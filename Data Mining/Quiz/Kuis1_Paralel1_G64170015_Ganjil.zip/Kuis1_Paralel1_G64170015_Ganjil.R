library("fpc")
library("factoextra")
library("mice")
library("cluster")

diabet = read.csv("diabet.csv",sep = ",")
diabet1 = read.csv("diabet.csv",sep = ",")
str(diabet)
summary(diabet)

md.pattern(diabet)
boxplot(diabet)

diabet$mass[is.na(diabet$mass)] <- mean (diabet$mass,na.rm= TRUE)
diabet$pedi[is.na(diabet$pedi)] <- mean (diabet$pedi,na.rm= TRUE)


for (i in 1:length(diabet$plas)) {
  diabet$plas[i] = (diabet$plas[i] - min(diabet$plas)) / (max(diabet$plas) - min(diabet$plas))
}

for (i in 1:length(diabet$insu)) {
  diabet$insu[i] = (diabet$insu[i] - min(diabet$insu)) / (max(diabet$insu) - min(diabet$insu))
}

diabet$class <- NULL
diabet$skin <- NULL
diabet$age <-NULL

kmeans.result <- kmeans(diabet, 5)
pamk.result <- pamk(diabet)
pam.result <- pam(diabet, 5)
plot(pam.result)